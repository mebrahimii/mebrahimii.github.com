// DO NOT MODIFY THIS FILE!
public interface CanBreathe {
    public void breathe();
    public void speak();
}

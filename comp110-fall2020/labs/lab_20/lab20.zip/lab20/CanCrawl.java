// Define an interface named CanCrawl.
// CanCrawl defines a single method named
// crawl, which takes no parameters and returns
// nothing


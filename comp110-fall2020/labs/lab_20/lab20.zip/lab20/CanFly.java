// DO NOT MODIFY THIS FILE!
public interface CanFly {
    public void fly();
}
